Store the downloaded outer release ZIP in the Releases folder on Google Drive. The ZIP does not include a nested copy of itself.
