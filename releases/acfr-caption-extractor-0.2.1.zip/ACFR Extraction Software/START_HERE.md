# ACFR Extraction Software 0.2.1

Open DEVELOPMENT_REPORT.md for actual results and limitations.
Run the application from Source Code; start with WINDOWS_INSTALL.md and README.md.
Development Results contains Juneau and Alaska outputs.
Validation Results/initial_holdout preserves the initial failure evidence.
Validation Results/auburn_regression contains corrected Auburn results, not a new independent holdout.
Validation Results/combined_regression contains all six CSV outputs for all three PDFs.
Run_in_Colab.ipynb is an optional user-run route to Google Drive (untested against your account).

This package contains no original PDFs, credentials, or virtual environment. Inputs
remain unchanged. Google Drive is the permanent home: upload this release to
ACFRS / ACFR Extraction Software / Releases, then extract/copy project folders as desired.
